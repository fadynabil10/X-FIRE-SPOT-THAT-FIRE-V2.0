import cv2
import numpy as np
import imutils
import sys

#print(sys.argv[1])
img = cv2.imread('centralafrica.jpg')
#img = cv2.imread(sys.argv[1])
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
#red
lower_range = np.array([161, 155, 84])
upper_range = np.array([179, 255, 255])
#lower_range = np.array([128, 132, 135])
#upper_range = np.array([180, 184, 182])
#print(len(lower_range))
mask = cv2.inRange(hsv, lower_range, upper_range)
#print(len(mask))
cv2.imshow('image', img)
cv2.imshow('mask', mask)

while(True):
   k = cv2.waitKey(5) & 0xFF
   if k == 27:
      break

cv2.destroyAllWindows()
cv2.imwrite('image.png',mask)
#################3
path ="image.png"
  
# reading the image in grayscale mode 
gray = cv2.imread(path, 0)   
# threshold 
th, threshed = cv2.threshold(gray, 100, 255,  
          cv2.THRESH_BINARY|cv2.THRESH_OTSU) 
  
# findcontours 
cnts = cv2.findContours(threshed, cv2.RETR_LIST,  
                    cv2.CHAIN_APPROX_SIMPLE)[-2] 
  
# filter by area 
s1 = 3
s2 = 20
xcnts = [] 
  
for cnt in cnts: 
    if s1<cv2.contourArea(cnt) <s2: 
        xcnts.append(cnt) 
  
# printing output 
print("Num of fire may be  :: {}".format(len(xcnts))) 
