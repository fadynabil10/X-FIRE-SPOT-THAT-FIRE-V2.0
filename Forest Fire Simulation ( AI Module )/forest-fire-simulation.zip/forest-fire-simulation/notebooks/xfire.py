import numpy as np
import pandas as pd

df = pd.read_csv("../data/forest-fires.csv")
df.columns = [ "x_coord", "y_coord", "month", "day", "ffmc", "dmc", "dc", "isi", "temp",
              "rh", "wind", "rain", "area" ]

df.head()




df.info()



from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler

le_month = LabelEncoder()
df["month"] = le_month.fit_transform(df["month"])

le_day = LabelEncoder()
df["day"] = le_day.fit_transform(df["day"])

# ss = StandardScaler()
# df["area"] = ss.fit_transform(df["area"].values.reshape(-1, 1))

mms = MinMaxScaler()
df["area"] = mms.fit_transform(df["area"].values.reshape(-1, 1))

df.head()



df.describe()


y = df.pop("area")
X = df

X.head()




y.head()


from keras.layers import Input, Dense
from keras.models import Model
from keras.optimizers import Adam

def build_model():

    fire_in = Input((12,))

    dense = Dense(12, activation="sigmoid")(fire_in)
    dense = Dense(1,  activation="linear")(dense)

    model = Model(inputs=fire_in, outputs=dense)

    adam = Adam(lr=0.01)

    model.compile(optimizer=adam, loss="mse")
    
    return model



from sklearn.model_selection import cross_val_score
from keras.wrappers.scikit_learn import KerasRegressor

np.random.seed(19)

# build_model().fit(X.values, y.values, batch_size=5, epochs=5000, verbose=2)

reg = KerasRegressor(build_fn=build_model, nb_epoch=20, verbose=0)
results = cross_val_score(reg, X.values, y.values, cv=10)
print("mean:", np.mean(results))
print(results)


from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X.values, y.values, test_size=0.2, random_state=19)

model = build_model()
model.fit(X_train, y_train, epochs=50, verbose=2, validation_data=(X_test, y_test),validation_split=0.1,shuffle=True)



Error=model.evaluate(x=X_test,y=y_test)


print("accuracy = ",(1-Error)*100)
